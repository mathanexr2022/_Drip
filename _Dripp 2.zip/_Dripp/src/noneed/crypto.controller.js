const crypto = require('../middlewares/crypto');

module.exports = class CryptoController {

    // E N C R Y P T I O N  
    static encrypt = async (req, res) => {

        try {

            let { data } = req.body;

            const result = await crypto.encrypt(data);

            res.status(200).send({
                data: result
            })

        } catch (error) {

            res.status(500).send({ message: "Internal Server Error" })

        }

    }

    // D E C R Y P T I O N 
    static decrypt = async (req, res) => {

        try {

            let { data } = req.body;

            const result = await crypto.decrypt(data);

            res.status(200).send({
                data: result
            })

        } catch (error) {

            res.status(500).send({ message: "Internal Server Error" })

        }

    }

}