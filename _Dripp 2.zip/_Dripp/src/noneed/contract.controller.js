const Web3 = require('../services/contract.service');

module.exports = class Web3Controller {

    
    static generateABI = async(req, res) => {

        try {
            
            let {contractAddress, chainId} = req.body;

            const result = await Web3.importAbi(contractAddress, chainId);

            return res.status(200).send({
                data: result
            })

        } catch (error) {
            
            return res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static importToken = async(req, res) => {

        try {
            
            let {contractAddress, chainId, walletAddress} = req.body;

            const result = await Web3.importTokenDetails(contractAddress, chainId, walletAddress);

            return res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static sendCoin = async(req, res) => {

        try {
            
            let {chainId, privateKey, receiver, gasLimit, maxFeePerGas, maxPriorityFeePerGas, amount} = req.body;

            const result = await Web3.sendCoin(chainId, privateKey, receiver, gasLimit, maxFeePerGas, maxPriorityFeePerGas, amount);

            return res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static sendToken = async(req, res) => {

        try {
            
            let {chainId, privateKey, receiver, contractAddress, amount, gasLimit, maxFeePerGas, maxPriorityFeePerGas} = req.body;

            const result = await Web3.sendToken(chainId, privateKey, receiver, contractAddress, amount, gasLimit, maxFeePerGas, maxPriorityFeePerGas);

            res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static signMessage = async(req, res) => {

        try {
            
            let { chainId, privateKey, message } = req.body;

            const result = await Web3.signMessage(chainId, privateKey, message);

            res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static verifyMessage = async(req, res) => {

        try {
            
            let { chainId, message, signature, address } = req.body;

            const result = await Web3.verifyMessage(chainId, message, signature, address);

            res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                message: "Internal Server Error"
            })

        }

    }

    static gasValues = async(req, res) => {
     
        try {

            let { chainId, receiver, amount } = req.body;

            const result = await Web3.getDefaultGasValues(chainId, receiver, amount);
            
            res.status(200).send({
                data: result
            })

        } catch (error) {
            
            res.status(500).send({
                nessage: "Internal Server Error"
            })

        }

    }

}
