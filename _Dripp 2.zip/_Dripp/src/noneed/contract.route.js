const express = require('express');
const router = express.Router();
const contractController = require("../controllers/contract.controller");

router.post("/generateABI", contractController.generateABI);
router.post("/importToken", contractController.importToken);
router.post("/sign", contractController.signMessage);
router.post("/verify", contractController.verifyMessage);
router.post("/gasValues", contractController.gasValues);
router.post("/sendCoin", contractController.sendCoin);
router.post("/sendToken", contractController.sendToken);

module.exports = router;