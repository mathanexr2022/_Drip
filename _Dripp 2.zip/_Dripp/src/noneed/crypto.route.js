const express = require('express');
const router = express.Router();
const CryptoController = require('../controllers/crypto.controller');

router.post("/encrypt", CryptoController.encrypt);
router.post("/decrypt", CryptoController.decrypt);

module.exports = router;