const express = require('express');
const router = express.Router();
const walletController = require("./wallet.controller");

router.post("/createMnemonics", walletController.createMnemonics);

router.post("/generateAccounts", walletController.generateAccounts);

router.post("/importWallet", walletController.importWallet);

router.post("/importAccount", walletController.importAccount);

module.exports = router;