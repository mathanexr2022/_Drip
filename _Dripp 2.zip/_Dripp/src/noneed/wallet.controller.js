const { response } = require("express");
const HDWallet = require("../services/wallet.service");


  // C R E A T E   M N E M O N I C S
  const  createMnemonics = async(req, res) => {
    try {

      let { entropyLength } = req.body;

      const result = await HDWallet.generateMnemonics(entropyLength);

      res.status(200).send({ data: result });

    } catch (error) {

      res.status(500).send({ message: "Internal Server Error" });

    }
  }

  // G E N E R A T E   A C C O U N T S
  const generateAccounts = async(req, res) => {
    try {

      let { mnemonics, password, index } = req.body;

      const result = await HDWallet.generateWallet(mnemonics, password, index);

      res.status(200).send({ data: result });

    } catch (error) {

      res.status(500).send({ message: "Internal Server Error" });

    }
  }

  // I M P O R T   W A L L E T
  const importWallet = async(req, res) => {
    try {

      let { mnemonics } = req.body;

      const result = await HDWallet.importWallet(mnemonics);

      res.status(200).send({ data: result });

    } catch (error) {

      res.status(500).send({ message: "Internal Server Error" });

    }
  }

  // I M P O R T   A C C O U N T
  const importAccount = async(req, res) => {
    try {

      let { privateKey } = req.body;

      const result = await HDWallet.importAccount(privateKey);

      res.status(200).send({ data: result });

    } catch (error) {

      res.status(500).send({ message: "Internal Server Error" })

    }
  }


  module.exports ={
    createMnemonics,
    generateAccounts,
    importWallet,
    importAccount

  }