const express = require('express');
const router = express.Router();
const tran = require('../controllers/transaction.controller.js');

router.post('/send/coin',tran.sendCoin);

router.post('/send/token',tran.sendToken);

router.post('/sign',tran.sign);

router.post('/gasvalues',tran.gasValues);

module.exports = router;