const express = require('express');
const router = express.Router();
const login = require('../controllers/login.controller');
const crypt = require('../controllers/crp')

router.post('/login/seed',login.createSeed);

router.post('/login/fetch/seed',login.fetchSeed);

router.post('/login/import/seed',login.importSeed);

router.post('/login/account',login.createAccount);

router.post('/login/import/account',login.importAccount);

router.post('/login/fetch/account',login.fetchAccount);
router.post('/crypt/encrypt',crypt.encrypt)
router.post('/crypt/decrypt',crypt.decrypt)


module.exports = router;