const crypto = require('crypto');
const { readFile, writeFile, readdir, rename } = require('fs/promises');

const algorithm = 'aes-256-ctr';

// let keys ;

/* KEY LENGTH IS DEPENDENT ON THE ALGORITHM, 
 * SUCH AS FOR AES192, IT'S 24 BYTES, AES256, IT'S 32 BYTES
*/

// var key = crypto.createHash('sha256').update(String(keys)).digest('base64').substr(0, 32);

/* UPDATE accepts a continuous stream of data like a buffer.
 * After calling the update() method we need to define the output for the hash (ie, hex, binary, base64)
 * We can define using digest() method on the object returned from the update() method
 * Creating 256 hash for key/password
 * 44 in length, but only substr(0,32)
*/



// ENCRYPT FUNCTION
const encrypt = async (buffer, password) => {
    try {
        var key = crypto.createHash('sha256').update(String(password)).digest('base64').substr(0, 32);

        //* INITIALIZATION VECTOR
        const iv = crypto.randomBytes(16);


        //* MAKE THE ENCRYPT FUNCTION
        const cipher = crypto.createCipheriv(algorithm, key, iv);

        const result = Buffer.concat([iv, cipher.update(buffer), cipher.final()])
        return {
            status: true,
            message: result.toString('hex')
        }

    } catch (error) {
        console.log(":: ENCRYPT_ERROR ::", error);
        return {
            status: false,
            message: "error"
        }

    }

}

// DECRYPT FUNCTION
const decrypt = async (encrypted, password) => {

    try {
        let key = crypto.createHash('sha256').update(String(password)).digest('base64').substr(0, 32);
        let ciphers = Buffer.from(encrypted, "hex");
        const iv = ciphers.slice(0, 16);
        ciphers = ciphers.slice(16);

        // MAKE THE DECRYPTER FUNCTION
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        var result = Buffer.concat([decipher.update(ciphers), decipher.final()]);
        console.log("RESULT", result.toString())
        // console.log("!213", Buffer.from(JSON.stringify(result)))
        let rem = result.toString()
        let return_data = JSON.parse(rem)
        console.log("🚀 ~ file: crypto.js:152 ~ decrypt ~ return_data", return_data)
        return {
            // status: true,
            // message: return_data
            return_data
        }

    } catch (error) {
        console.log(":: DECRYPT_ERROR ::", error)
        return {
            status: false,
            message: "error"
        }
    }

}



module.exports = {
    encrypt,
    decrypt
}
