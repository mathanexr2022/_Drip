const ethers = require('ethers');
const bip39 = require('bip39');

// D E R I V A T I O N    P A T H
const path = "m/44'/60'/0'"; // The default path for Ethereum in an HD Wallet

var index = 0;

// P A S S P H R A S E
//const password = "DoYouKnotrhhtrfhthtffthtfhwMyPassword";
//const mn ="visa evidence much acoustic strike happy clay supply harbor latin object obscure";


    // G E N E R A T E    M N E M O N I C S
    const generateMnemonics = async (entropyLength) => {

        try {

            const entropy = ethers.utils.randomBytes(entropyLength);

            const mnemonics = bip39.entropyToMnemonic(entropy);


            let data = {
                mnemonics: mnemonics
            }

            return {
                status: true,
                message: data
            };

        } catch (error) {

            console.log(":: GENERATE_MNEMONICS_ERROR ::", error);

            return {
                status: false,
                message: "Invalid Entropy"
            }

        }

    }

    // G E N E R A T E    M U L T I P L E    A C C O U N T S 
    const generateAccounts = async (parentKey, account) => {
        try {
            let child = ethers.utils.HDNode.fromExtendedKey(parentKey);
            let change = "0/";
            // console.log("ETH :: :", child.derivePath(change + account));
            let childWallet = await child.derivePath(change + account);
            index++;
            let data = {
                privateKey: childWallet.privateKey,
                address: childWallet.address
            }
            console.log("🚀 ~ file: wallet.service.js:59 ~ generateAccounts ~ data", data)
            return {
                status: true,
                message: data
            }
        } catch (error) {
            console.log(":: GENERATE_ACCOUNTS_ERROR ::", error);
        }
    }

    // G E N E R A T E    N E W    W A L L E T
    const generateWallet = async (mnemonic,  index) => {

        try {

            const HDNode = ethers.utils.HDNode.fromMnemonic(mnemonic);

            const xpriv = HDNode.extendedKey;

            return generateAccounts(xpriv, index);

            // return {
            //     status : true,
            //     message : generateAccounts(xpriv, index)
            // }

        } catch (error) {

            console.log(":: GENERATE_WALLET_ERROR ::", error);

            return {
                status: false,
                message: "Invalid Mnemonics"
            }

        }

    }

    // I M P O R T    W A L L E T    U S I N G    M N E M O N I C S
    const importWallet = async (mnemonics) => {

        try {

            const HDNode = ethers.utils.HDNode.fromMnemonic(mnemonics);

            const xpriv = HDNode.extendedKey;

            index = 0;
            console.log("index::::"+  index);

            return await generateAccounts(xpriv, 0)

        } catch (error) {

            console.log(":: IMPORT_WALLET_ERROR ::", error)

            return {
                status: false,
                message: "Invalid Mnemonics"
            }

        }

    }

    // I M P O R T    A N    A C C O U N T    U S I N G    P R I V A T E    K E Y
    const importAccount = async (privateKey) => {

        try {

            let data = {
                privateKey: privateKey,
                address: (new ethers.Wallet(privateKey).address)
            }

            index++;
            console.log("index::", index)

            return {
                status: true,
                message: data
            }

        } catch (error) {

            console.log(":: IMPORT_ACCOUNT_ERROR ::", error);

            return {
                status: false,
                message: "Invalid Private Key"
            }

        }

    }

module.exports={
    importAccount,
    importWallet,
    generateWallet,
    generateMnemonics,
    generateAccounts

}