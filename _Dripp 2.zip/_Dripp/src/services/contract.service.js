const ethers = require("ethers");
const config = require("../configs/wallet.config");
const contract_abi = require("./token.json");

var provider;

// I N I T I A L I Z E    W E B 3
const initializeWeb3 = async (chain) => {
  try {
    provider = new ethers.providers.JsonRpcProvider(chain);

    return {
      status: true,
      message: provider,
    };
  } catch (error) {
    console.log(":: INITIALIZE_WEB3_ERROR :: ", error);

    return {
      status: false,
      message: "error",
    };
  }
};

// P R O V I D E R
const selectProvider = async (chainId) => {
  try {
    if (chainId == "8001") {
      const chain = config.wallet.polygon.provider;
      // console.log("fhgfhgvhg",chain);

      chain_id = chainId;

      let info = await initializeWeb3(chain);

      return info;
    } else if (chainId == "3") {
      console.log("Asdaksgfkaunysfhqerfqwr", chainId);
      const chain = constants.wallet.ethereum.provider;
      console.log("Asdaksgfkaunysfhqerfqwr", chain);

      chain_id = chainId;

      let info = await initializeWeb3(chain);

      return info;
    }
  } catch (error) {
    console.log(":: SELECT_PROVIDER ::", error);

    return {
      status: false,
      message: "error",
    };
  }
};

// S E N D    C O I N S
const sendCoins = async (
  chainId,
  privateKey,
  receiver,
  gasLimit,
  gasPrice,
  amount
) => {
  let status = false;

  try {
    // await initializeWeb3();

    await selectProvider(chainId);

    let wallet = new ethers.Wallet(privateKey);
    console.log("WALLET ::", wallet.address);

    let walletSigner = wallet.connect(provider);
    console.log("SIGNER ::", walletSigner.address);

    let gasLimit = await provider.estimateGas({
      to: receiver,
      value: ethers.utils.parseEther(amount),
    });

    console.log("GAS LIMIT :: ", gasLimit.toString());

    let gasPrice = await provider.getGasPrice();

    console.log("GAS PRICE :: ", gasPrice.toString());

    // console.log("21312312", ethers.BigNumber.from(txn.gasLimit));

    let getFee = await provider.getFeeData();
    console.log("lastBaseFeePerGas", getFee.lastBaseFeePerGas.toString());
    console.log("maxFeePerGas", getFee.maxFeePerGas.toString());
    console.log("maxPriorityFeePerGas", getFee.maxPriorityFeePerGas.toString());
    console.log("gasPrice", getFee.gasPrice.toString());

    let network = await provider.getNetwork();
    console.log("chainId", network.chainId);

    const tx = {
      chainId: network.chainId,
      type: 2,
      from: walletSigner.address,
      to: receiver,
      value: ethers.utils.parseEther(amount),
      nonce: provider.getTransactionCount(wallet.address, "latest"),
      gasLimit: ethers.BigNumber.from(gasLimit), // ethers.utils.parseEther(txn.gasLimit), //provider.estimateGas(), //ethers.utils.hexlify('100000'), // 100000
      maxFeePerGas: getFee.maxFeePerGas,
      maxPriorityFeePerGas: getFee.maxPriorityFeePerGas,
      // gasPrice: ethers.BigNumber.from(gasPrice) //provider.getGasPrice()
    };

    let hash;

    // let rawTransaction = await wallet.signTransaction(tx);

    // let serialize = await ethers.utils.serializeTransaction(tx);

    // console.log("RAW_TXN", rawTransaction)
    // console.log("SERIALIZE", serialize)

    await walletSigner.sendTransaction(tx).then(async (transaction) => {
      console.log("TRANSACTION HASH :: ", transaction.hash);

      hash = transaction.hash;
      status = true;
    });

    return {
      status: status,
      message: {
        transactionHash: hash,
      },
    };
  } catch (error) {
    console.log(":: SEND_COIN_ERROR :: ", error);

    return {
      status: status,
      message: error.reason,
    };
  }
};

// S I G N    M E S S A G E
const signMessage = async (chainId, privateKey, message) => {
  try {
    await selectProvider(chainId);

    let wallet = new ethers.Wallet(privateKey);
    console.log("WALLET ::", wallet.address);

    let walletSigner = wallet.connect(provider);
    console.log("SIGNER ::", walletSigner.address);

    const signature = await walletSigner.signMessage(message);

    console.log("SIGNATURE", signature);

    return {
      status: true,
      message: signature,
    };
  } catch (error) {
    console.log(":: SIGN_MESSAGE_ERROR ::", error);

    return {
      status: false,
      message: error,
    };
  }
};

// V E R I F Y    M E S S A G E
const verifyMessage = async (chainId, message, signature, address) => {
  try {
    await selectProvider(chainId);

    const signerAddress = await ethers.utils.verifyMessage(message, signature);
    // console.log("adddd"+signerAddress)
    // console.log("adddd"+address)

    if (signerAddress == address) {
      return {
        status: true,
        message: "Verification is successful",
      };
    } else {
      return {
        status: false,
        message: "Verification is failed",
      };
    }
  } catch (error) {
    console.log(":: VERIFY_MESSAGE_ERROR ::", error);

    return {
      status: false,
      message: error,
    };
  }
};

// S E N D    T O K E N
const sendToken = async (
  chainId,
  privateKey,
  receiver,
  contractAddress,
  amount,
  gasLimit,
  maxFeePerGas,
  maxPriorityFeePerGas
) => {
  try {
    await selectProvider(chainId);
    //  let contract_abi = (await importAbi(contractAddress, chainId)).message;

    let wallet = new ethers.Wallet(privateKey, provider);
    // console.log("WALLET ::", wallet.address);

    let walletSigner = wallet.connect(provider);
    //console.log("SIGNER ::", walletSigner.address);

    const contract = new ethers.Contract(contractAddress, contract_abi, wallet);

    const contract_decimal = await contract.decimals();

    // console.log("Adsasdas", contract_decimal);

    // let parameters = {
    //   gasLimit : gasLimit
    // }

    let token_amount = await ethers.utils.parseUnits(amount, contract_decimal);

    //console.log("TOKEN::", token_amount.toString());

    let hash;

    let params = {
      gasLimit: ethers.BigNumber.from(gasLimit),
      maxFeePerGas: ethers.BigNumber.from(maxFeePerGas),
      maxPriorityFeePerGas: ethers.BigNumber.from(maxPriorityFeePerGas),
    };

    await contract
      .transfer(receiver, token_amount, params)
      .then(async (transaction) => {
        // console.log("TRANSACTION HASH :: ", transaction.hash);

        hash = transaction.hash;
        // console.log(hash);
      });

    return {
      status: true,
      message: hash,
    };
  } catch (error) {
    console.log("SEND TOKEN :: ", error);

    return {
      status: false,
      message: "Send Token",
    };
  }
};

// D E F A U L T    G A S    V A L U E S
const getDefaultGasValues = async (chainId, receiver, amount) => {
  try {
    await selectProvider(chainId);

    let getFee = await provider.getFeeData();

    let gasLimit = await provider.estimateGas({
      to: receiver,
      value: ethers.utils.parseEther(amount),
    });

    let data = {
      lastBaseFeePerGas: ethers.utils.formatUnits(
        getFee.lastBaseFeePerGas,
        "wei"
      ),
      maxFeePerGas: ethers.utils.formatUnits(getFee.maxFeePerGas, "wei"),
      maxPriorityFeePerGas: ethers.utils.formatUnits(
        getFee.maxPriorityFeePerGas,
        "wei"
      ),
      gasPrice: ethers.utils.formatUnits(getFee.gasPrice, "wei"),
      gasLimit: ethers.utils.formatUnits(gasLimit, "wei"),
    };

    console.log("getFee", data);

    return {
      status: true,
      message: data,
    };
  } catch (error) {
    console.log(":: GET_DEFAULT_GAS_FEES ::", error);

    return {
      status: false,
      message: "error",
    };
  }
};

// I M P O R T    T O K E N    D E T A I L S
const importTokenDetails = async (contractAddress, chainid, walletAddress) => {
  try {
    await selectProvider(chainid);

    const contract = await new ethers.Contract(
      contractAddress,
      contract_abi,
      provider
    );
    //  console.log("ugygkuygluigui",provider)

    const contract_balance = await contract.balanceOf(walletAddress);

    const contract_decimal = await contract.decimals();

    const contract_name = await contract.name();

    const contract_symbol = await contract.symbol();

    console.log(contract_balance, contract_decimal, contract_name);

    let balance = await ethers.utils.formatUnits(
      contract_balance,
      contract_decimal
    );

    return {
      status: true,
      tokenContract: contractAddress,
      tokenName: contract_name,
      tokenDecimal: String(contract_decimal),
      tokenSymbol: contract_symbol,
      tokenBalance: balance,
    };
  } catch (error) {
    console.log("ERROR", error);

    return {
      status: false,
      message: "tokenimp",
    };
  }
};

// S E N D    C O I N
const sendCoin = async (
  chainId,
  privateKey,
  receiver,
  gasLimit,
  maxFeePerGas,
  maxPriorityFeePerGas,
  amount
) => {
  let status = false;

  try {
    // await initializeWeb3();

    await selectProvider(chainId);

    let wallet = new ethers.Wallet(privateKey);
    console.log("WALLET ::", wallet.address);

    let walletSigner = wallet.connect(provider);
    console.log("SIGNER ::", walletSigner.address);

    console.log("GAS LIMIT :: ", gasLimit, gasLimit.toString());

    console.log("GAS LIMIT FROM STRING", ethers.BigNumber.from("21000"));

    let gasPrice = await provider.getGasPrice();

    console.log("GAS PRICE :: ", gasPrice.toString());

    console.log(
      "maxFeePerGas",
      ethers.BigNumber.from("16"),
      ethers.BigNumber.from("1500000032")
    );

    let getFee = await provider.getFeeData();

    console.log("GET FEE", getFee);

    console.log("lastBaseFeePerGas", getFee.lastBaseFeePerGas.toString());
    console.log("maxFeePerGas", getFee.maxFeePerGas.toString());
    console.log("maxPriorityFeePerGas", getFee.maxPriorityFeePerGas.toString());
    console.log("gasPrice", getFee.gasPrice.toString());

    let network = await provider.getNetwork();
    console.log("chainId", network.chainId);

    const tx = {
      chainId: network.chainId,
      type: 2,
      from: walletSigner.address,
      to: receiver,
      value: ethers.utils.parseEther(amount),
      nonce: provider.getTransactionCount(wallet.address, "latest"),
      gasLimit: ethers.BigNumber.from(gasLimit), //gasLimit is 21000 // ethers.utils.parseEther(txn.gasLimit), //provider.estimateGas(), //ethers.utils.hexlify('100000'), // 100000
      maxFeePerGas: ethers.BigNumber.from(maxFeePerGas),
      maxPriorityFeePerGas: ethers.BigNumber.from(maxPriorityFeePerGas),
      // gasPrice: ethers.BigNumber.from(gasPrice) //provider.getGasPrice()
    };

    let hash;

    // let rawTransaction = await wallet.signTransaction(tx);

    // let serialize = await ethers.utils.serializeTransaction(tx);

    // console.log("RAW_TXN", rawTransaction)
    // console.log("SERIALIZE", serialize)

    await walletSigner.sendTransaction(tx).then(async (transaction) => {
      console.log("TRANSACTION HASH :: ", transaction.hash);

      hash = transaction.hash;
      status = true;
    });

    return {
      status: status,
      message: {
        transactionHash: hash,
      },
    };
  } catch (error) {
    console.log(":: SEND_COIN_ERROR :: ", error);

    return {
      status: status,
      message: error.reason,
    };
  }
};

//signMessage("8001","6e83567fd8e5740dd2859af1f86dfa31f091b97bc6137fb71a68525dfd715384","sec")

//importTokenDetails("0xe6b8a5CF854791412c1f6EFC7CAf629f5Df1c747","8001","0x0d81db5dd3576377C414FA325D2F41d6eA3A3cA2")

//  sendToken("8001","6e83567fd8e5740dd2859af1f86dfa31f091b97bc6137fb71a68525dfd715384","0x79Fb2A65920B7f211CF294C193F85da260eABA0A","0x5aDcac4f2C04F7A7910962Aa254D0Af31CE1F11b","0.001","50000","1700000024","1700000000")

// verifyMessage(
//   "8001",
//   "sec",
//   "0x7621a6ab9b51613431afed459c57abd421cc475c0955199bbfb6ad50fa1405647ffb426c71a646da17c9440c394688eeed652db823e77bc9265b71b38b0292f71c",
//   "0xFf395c390B405dB26915021e93c6d405ece64c5F"
// );
module.exports = {
  sendCoins,
  signMessage,
  verifyMessage,
  sendToken,
  getDefaultGasValues,
  sendCoin,
  importTokenDetails,
};
