
var currentSearchResult = "example";

let format =
{
  "data": {
    "type": "HD Key Tree",
    "data": {
      "mnemonic": "salmon shadow worry month price oval satoshi general venture soon report host",
      "numberOfAccounts": 1,
      "hdPath": "m/44'/60'/0'/0"
    },
    "privateKeys": [
      "3ad3dab8018787a800deb7a046fa7fb81a3b5fe2b7640031d4101f9b4dc0873d",
      "3ad3dab8018787a800deb7a046fa7fb81a3b5fe2b7640031d4101f9b4dc0873d",
      "3ad3dab8018787a800deb7a046fa7fb81a3b5fe2b7640031d4101f9b4dc0873d",
    ]
  }
}
let j = "uygujyg n,mn w general venture soon report host";
const re = async () => {
  //console.log(format);
  //  var json = JSON.parse(format);
  // json.push("privateKeys" + currentSearchResult);
  //   fs.writeFile("results.json", JSON.stringify(json));
  format.data.privateKeys[3] = "3ad3dab8018787a800deb7a046fa7fb81a3b5fe2b7640031d4101f9b4dc0873d";
  format.data.data.mnemonic = j;
  console.log(format);
};
re()

