require('dotenv').config();

// TODO DATABASE




module.exports = {

    wallet :{
        polygon: {
            provider : process.env.PROVIDER_POLYGON,
            explorer: {
                url: "https://api-testnet.polygonscan.com",
                apiKey: process.env.EXPLORER_API_KEY_POLYGON
            }
        },
        ethereum: {
            provider : process.env.PROVIDER_ETHEREUM,
            explorer: {
                url: "https://api.etherscan.io",
                apiKey: process.env.EXPLORER_API_KEY_ETHEREUM
            }
        },
        binance: {
            provider : process.env.PROVIDER_BINANCE,
            explorer: {
                url: "",
                apiKey: process.env.EXPLORER_API_KEY_ETHEREUM
            }

        }
    }

}