var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var cors = require('cors');

// S W A G G E R    D O C U M E N T A T I O N
var swaggerUi = require('swagger-ui-express');
var YAML = require('yamljs');
var swaggerDocument = YAML.load('./swagger.yaml');

var walletRouter = require('./routes/login');
var contractRouter = require('./routes/transaction');
//var cryptoRouter = require('./routes/crypto.route');

var app = express();

app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'DELETE', 'UPDATE', 'PUT', 'PATCH']
}));
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// R O U T E S
app.use('/wallet', walletRouter);
app.use('/contract', contractRouter);
// app.use('/crypto', cryptoRouter);

module.exports = app;
