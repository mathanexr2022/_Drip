const HDWallet = require("../services/wallet.service");
const crypto = require("../middlewares/crypto");
const format_data = require('../../format')

const createSeed = async (req, res) => {
  try {
    let password = req.body.password;
    let src_data;
    const result = await HDWallet.generateMnemonics(16);
    console.log("🚀 ~ file: login.controller.js:10 ~ createSeed ~ result", result)
    format_data.data.mnemonic = result.message.mnemonics;
    src_data = JSON.stringify(format_data)
    console.log("🚀 ~ file: login.controller.js:13 ~ createSeed ~ src_data", src_data)
    const encrypt = await crypto.encrypt(src_data, password);
    //chrome storage ::::::::::::::::::::::::::::::
    res.status(200).send({
      data: encrypt,
    });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
    console.log("ERROR::::::::" + e);
  }
};

const fetchSeed = async (req, res) => {
  try {
    console.log('printing request bdy', req.body)
    // let { data, password } = req.body;
    let data = req.body.data
    console.log("🚀 ~ file: login.controller.js:29 ~ fetchSeed ~ data", data)

    let password = req.body.password
    // console.log('checking for type of data ',typeof(password))
    const mnemonics = await crypto.decrypt(data, password);
    console.log("🚀 ~ file: login.controller.js:34 ~ fetchSeed ~ mnemonics", mnemonics)

    // console.log("🚀 ~ file: login.controller.js:33 ~ fetchSeed ~ mnemonics", mnemonics.return_data.data.mnemonic)
    res.status(200).send({
      data: mnemonics
    });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
    console.log("ERROR::::::::" + e);
  }
};

const importSeed = async (req, res) => {
  try {
    let { mnemonics, password } = req.body;
    let src_data;

    const result = await HDWallet.importWallet(mnemonics);
    console.log("🚀 ~ file: login.controller.js:46 ~ importSeed ~ result", result)
    format_data.data.mnemonic = mnemonics;
    src_data = JSON.stringify(format_data)

    const encrypt = await crypto.encrypt(src_data, password);
    console.log("🚀 ~ file: login.controller.js:51 ~ importSeed ~ encrypt", encrypt)
    // chrome storage ::::::::::::::::::::::::::::::
    // encrypt for(chrome storage)
    // result is for UI
    res.status(200).send({
      data: encrypt,
      key: result,
    });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
    console.log("ERROR::::::::" + e);
  }
};

const createAccount = async (req, res) => {
  // mnemonics will come from chrome storage frontend
  // password will come from session storage
  // index will come from frontend ( according to the index of the wallet)
  // index will save into chrome storage from frontend
  try {
    let { data, password } = req.body;
    let response_data;

    console.log("create account req body", req.body)
    const mnemonic = await crypto.decrypt(data, password);
    console.log("🚀 ~ file: login.controller.js:82 ~ createAccount ~ mnemonic", mnemonic)

    let index = mnemonic.return_data.data.numberOfAccounts
    console.log("🚀 ~ file: login.controller.js:85 ~ createAccount ~ index", index)
    let nm_data = mnemonic.return_data.data.mnemonic
    console.log("🚀 ~ file: login.controller.js:87 ~ createAccount ~ nm_data", nm_data)


    const result = await HDWallet.generateWallet(nm_data, index);
    console.log("🚀 ~ file: login.controller.js:88 ~ createAccount ~ result", result)

    if (result.message.address) {
      index++
      mnemonic.return_data.data.numberOfAccounts = index
      console.log("🚀 ~ file: login.controller.js:82 ~ createAccount ~ mnemonic========>", mnemonic.return_data)

      response_data = JSON.stringify(mnemonic.return_data)
    }

    const encrypt = await crypto.encrypt(response_data, password);
    console.log("🚀 ~ file: login.controller.js:84 ~ createAccount ~ encrypt", encrypt)

    res.status(200).send({ address: result.message.address, data: encrypt });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
  }
};


//TODO: Validation,Error handling,Strict 
const importAccount = async (req, res) => {
  // index will save into chrome storage from frontend
  try {
    let { privateKey, password, data } = req.body;
    console.log("🚀 ~ file: login.controller.js:106 ~ importAccount ~ result", req.body)

    //* retrieving the public address
    const result = await HDWallet.importAccount(privateKey);
    console.log("🚀 ~ file: login.controller.js:121 ~ importAccount ~ result", result)
    let Privatekey = result.message.privateKey


    //* Decrypting the data passed
    const mnemonics = await crypto.decrypt(data, password);
    console.log("🚀 ~ file: login.controller.js:116 ~ importAccount ~ mnemonics", mnemonics)


    //* Appending the data to decrypt
    let mnemonics_data = mnemonics.return_data.privateKeys
    let index = mnemonics.return_data.data.numberOfAccounts
    mnemonics_data.push(Privatekey)


    //* Updating the number of accounts after pushing the private key to data object
    if (mnemonics.return_data.privateKeys) {
      index++
      mnemonics.return_data.data.numberOfAccounts = index
    }

    console.log("🚀 ~ file: login.controller.js:116 ~ importAccount ~ mnemonics=====>", mnemonics.return_data)

    //* Converting the datatype to string
    let to_encrypt = JSON.stringify(mnemonics.return_data)


    //* Encrypting the data after updating 
    const encrypt = await crypto.encrypt(to_encrypt, password);

    res.status(200).send({ data: result, key: encrypt });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
  }
};

const fetchAccount = async (req, res) => {
  try {
    let { data, index, password, isImported } = req.body;
    // console.log("🚀 ~ file: login.controller.js:148 ~ fetchAccount ~ req.body", typeof(index))
    // console.log("🚀 ~ file: login.controller.js:148 ~ fetchAccount ~ req.body", isImported)

    // console.log("🚀 ~ file: login.controller.js:148 ~ fetchAccount ~ req.body", req.body)
    let p_key;
    const accountDetails = await crypto.decrypt(data, password);
    console.log("🚀 ~ file: login.controller.js:148 ~ fetchAccount ~ accountDetails", accountDetails.return_data.data.mnemonic)
    console.log("🚀 ~ file: login.controller.js:148 ~ fetchAccount ~ accountDetails.men", accountDetails)

    if (isImported == true) {
      p_key = await accountDetails.return_data.privateKeys[index];
      console.log("🚀 ~ file: login.controller.js:153 ~ fetchAccount ~ pkey if", p_key)
    }
    else {
      let uu = accountDetails.return_data.data.mnemonic
      console.log("🚀 ~ file: login.controller.js:174 ~ fetchAccount ~ uu", uu)
      const result = await HDWallet.generateWallet(uu, index);
      console.log("🚀 ~ file: login.controller.js:165 ~ fetchAccount ~ result", result)
      p_key = result.message.privateKey;
      console.log("🚀 ~ file: login.controller.js:162 ~ fetchAccount ~ p_key else", p_key)
    }

    res.status(200).send({ data: p_key });
  } catch (e) {
    res.status(500).send({ message: "Internal Server Error" });
    console.log("ERROR::::::::" + e);
  }
};


module.exports = {
  createSeed,
  importSeed,
  createAccount,
  importAccount,
  fetchSeed,
  fetchAccount,
};
