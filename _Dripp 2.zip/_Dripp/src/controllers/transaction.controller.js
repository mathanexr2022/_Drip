const crypto = require("../middlewares/crypto");
const Web3 = require("../services/contract.service");
const HDWallet = require("../services/wallet.service");


//* Send coin  
const sendCoin = async (req, res) => {
  let pkey;
  try {
    // let {
    //   chainId,
    //   data,
    //   pasw,
    //   index,
    //   receiver,
    //   gasLimit,
    //   maxFeePerGas,
    //   maxPriorityFeePerGas,
    //   amount,
    //   isImported,
    // } = req.body;
    // let impr = req.body
    // console.log("🚀 ~ file: transaction.controller.js:21 ~ sendCoin ~ requestbody", impr)

    // const accountDetails = await crypto.decrypt(impr.data, impr.pasw);
    // console.log("🚀 ~ file: transaction.controller.js:21 ~ sendCoin ~ accountDetails", accountDetails)

    // if(impr.isImported === true) {
    //   console.log("🚀 ~ file: transaction.controller.js:21 ~ sendCoin ~ isImported =============")
    //   pkey = await accountDetails.return_data.privateKeys[impr.index];
    //   console.log("🚀 ~ file: transaction.controller.js:24 ~ sendCoin ~ pkey======>", pkey)
    // }
    // else {
    //   console.log("printing test =========>")
    //   const pvt = await HDWallet.generateWallet(
    //     accountDetails.return_data.data.mnemonic,
    //     index
    //   );
    //   pkey = pvt.message.privateKey;
    //   console.log("🚀 ~ file: transaction.controller.js:31 ~ sendCoin ~ pkey", pkey)
    // }
    // const result = await Web3.sendCoin(
    //   impr.chainId,
    //   pkey,
    //   impr.receiver,
    //   impr.gasLimit,
    //   impr.maxFeePerGas,
    //   impr.maxPriorityFeePerGas,
    //   impr.amount
    // );



    let input_data = req.body
    console.log("🚀 ~ file: transaction.controller.js:55 ~ sendCoin ~ input_data", input_data)
    const fetchAccount = await crypto.decrypt(input_data.data,input_data.password)
    let private_key;
    if(input_data.isImported == true){
      private_key = await fetchAccount.return_data.privateKeys[input_data.index];
    }
    else if(input_data.isImported == false){
      const privateKey = await HDWallet.generateWallet(fetchAccount.return_data.data.mnemonic,input_data.index)
      private_key = privateKey.message.privateKey
    }
    const result = await Web3.sendCoin(input_data.chainId,private_key,input_data.receiver,input_data.gasLimit,input_data.maxFeePerGas,input_data.maxPriorityFeePerGas,input_data.amount)
    return res.status(200).send({
      data: result,
    });
  } catch (e) {
    res.status(500).send({
      message: "Internal Server Error",
    });
  }
};

const sendToken = async (req, res) => {
  let pkey;
  try {
    let {
      chainId,
      data,
      password,
      index,
      receiver,
      contractAddress,
      amount,
      gasLimit,
      maxFeePerGas,
      maxPriorityFeePerGas,
      isImported,
    } = req.body;
    console.log("🚀 ~ file: transaction.controller.js:93 ~ sendToken ~ request body", req.body)

    const accountDetails = await crypto.decrypt(data, password);
    console.log("🚀 ~ file: transaction.controller.js:93 ~ sendToken ~ accountDetails", accountDetails)

    if (isImported) {
    console.log("🚀 ~ file: transaction.controller.js:93 ~ sendToken ~ privateKeys", accountDetails.return_data.privateKeys[index])

      pkey = await accountDetails.return_data.privateKeys[index]
      console.log("🚀 ~ file: transaction.controller.js:99 ~ sendToken ~ pkey", pkey)
      
    } else {
      const pvt = await HDWallet.generateWallet(
        accountDetails.return_data.data.mnemonic,
        index
      );
      console.log("🚀 ~ file: transaction.controller.js:106 ~ sendToken ~ pvt", pvt)
      pkey = pvt.message.privateKey;
      console.log("🚀 ~ file: transaction.controller.js:107 ~ sendToken ~ pkey======>", pkey)
    }
    const result = await Web3.sendToken(
      chainId,
      pkey,
      receiver,
      contractAddress,
      amount,
      gasLimit,
      maxFeePerGas,
      maxPriorityFeePerGas
    );
    console.log("🚀 ~ file: transaction.controller.js:120 ~ sendToken ~ result", result)

    res.status(200).send({
      data: result,
    });
  } catch (e) {
    res.status(500).send({
      message: "Internal Server Error",
    });
  }
};


//* arjun told to hold sign api.
const sign = async (req, res) => {
  let pkey;
  try {
    let { chainId, data, message, pasw, index, isImported, publicaddress } =
      req.body;
    const accountDetails = await crypto.decrypt(data, pasw);
    if (isImported) {
      pkey = await accountDetails.privateKey[index];
    } else {
      const pvt = await HDWallet.generateWallet(
        accountDetails.mnemonics,
        index
      );
      pkey = pvt.privateKey;
    }
    const result = await Web3.signMessage(chainId, pkey, message);
    const verify = await Web3.verifyMessage(
      chainId,
      message,
      result.message,
      publicaddress
    );

    res.status(200).send({
      data: verify.status,
    });
  } catch (e) {
    res.status(500).send({
      message: "Internal Server Error",
    });
  }
};

const gasValues = async (req, res) => {

  try {

    let { chainId, receiver, amount } = req.body;

    const result = await Web3.getDefaultGasValues(chainId, receiver, amount);

    res.status(200).send({
      data: result
    })

  } catch (error) {

    res.status(500).send({
      message: "Internal Server Error"
    })

  }

}


module.exports = {
  sendCoin,
  sendToken,
  sign,
  gasValues
}