const crypto = require('crypto');
const { readFile, writeFile, readdir, rename } = require('fs/promises');

const algorithm = 'aes-256-ctr';

// ENCRYPT FUNCTION
const encrypt = async (req, res) => {
    try {
        let { buffer, password } = req.body
        var key = crypto.createHash('sha256').update(String(password)).digest('base64').substr(0, 32);

        //* INITIALIZATION VECTOR
        const iv = crypto.randomBytes(16);


        //* MAKE THE ENCRYPT FUNCTION
        const cipher = crypto.createCipheriv(algorithm, key, iv);

        const result = Buffer.concat([iv, cipher.update(buffer), cipher.final()])
        return res.status(200).send({
            status: true,
            message: result.toString('hex')
        });
        // return {
        //     status: true,
        //     message: result.toString('hex')
        // }

    } catch (error) {
        console.log(":: ENCRYPT_ERROR ::", error);
        return res.status(200).send({
            status: false,
            message: "error"
        });

    }

}

// DECRYPT FUNCTION
const decrypt = async (req, res) => {

    try {
        let { encrypted, password } = req.body
        let key = crypto.createHash('sha256').update(String(password)).digest('base64').substr(0, 32);
        let ciphers = Buffer.from(encrypted, "hex");
        const iv = ciphers.slice(0, 16);
        ciphers = ciphers.slice(16);

        // MAKE THE DECRYPTER FUNCTION
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        var result = Buffer.concat([decipher.update(ciphers), decipher.final()]);
        console.log("RESULT", result.toString())
        // console.log("!213", Buffer.from(JSON.stringify(result)))
        let rem = result.toString()
        let return_data = JSON.parse(rem)
        console.log("🚀 ~ file: crypto.js:152 ~ decrypt ~ return_data", return_data)
        return res.status(200).send({
            status: true,
            message: return_data
        });

    } catch (error) {
        console.log(":: DECRYPT_ERROR ::", error)
        return {
            status: false,
            message: "error"
        }
    }

}



module.exports = {
    encrypt,
    decrypt
}
