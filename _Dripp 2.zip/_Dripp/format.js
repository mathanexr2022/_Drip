const format = { 
  type: 'HD Key Tree', 
  data: {
    mnemonic: '',
    numberOfAccounts:0,
    hdPath: "m/44'/60'/0'/0"
  },
  privateKeys: [],

}
module.exports = format