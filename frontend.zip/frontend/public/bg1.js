try {

    chrome.tabs.onload.addListener(function(tabId, changeInfo, tab) {

        if (domains.contains(tab.url)) {
            chrome.browserAction.setPopup({
                tabId: tabId,
                popup: 'index.html'
            });
        } else {
            chrome.browserAction.setPopup({
                tabId: tabId,
                popup: 'index.html'
            });
        }

        // if(changeInfo.status == 'complete') {

        //     chrome.scripting.executeScript({
        //         files: ['contentScript.js'],
        //         target: {tabId: tab.id}
        //     });

        // }

    });

} catch (error) {
 
    console.log(":: ERROR ::", error);

}