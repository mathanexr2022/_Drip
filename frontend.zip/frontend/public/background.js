// chrome.alarms.create({
//   periodInMinutes: 20 / 60,
// });

// chrome.alarms.onAlarm.addListener((alarm) => {
//   const notificationTime = 10000;

//   this.registration.showNotification("DRIPP", {
//     body: `${notificationTime} Transaction is successful`,
//     icon: "icon.png",
//   });
// });

chrome.runtime.onMessage.addListener(function (response, sender, sendResponse) {
  console.log(response);
  console.log(sender);
  console.log(sendResponse);

  var url = chrome.runtime.getURL("./index.html");

  chrome.windows.create({
    url: url,
    type: "popup",
    focused: true,
    height: 300,
    width: 350,
  });
});

chrome.windows.onRemoved.addListener((windowId) => {
  console.log(`Closed window: ${windowId}`);
});

chrome.windows.onRemoved.removeListener((windowId) => {
  console.log(`Closed windows: ${windowId}`);
});
