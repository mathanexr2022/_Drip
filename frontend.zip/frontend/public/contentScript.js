const buttonTag = document.getElementsByClassName("trigger");

buttonTag[0].addEventListener("click", () => {
  chrome.runtime.sendMessage("tefahdbshdg");
});
