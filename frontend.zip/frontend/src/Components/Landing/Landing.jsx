import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Landing.css';

function Landing() {

    let navigate = useNavigate();

    return (
        <div className='container'>
            <button className="button button1" onClick={() => navigate('/importWallet')}>
                ImportWallet
            </button>
            <button className="button button2" onClick={() => navigate('/createWallet')}>
                Create Wallet
            </button>
            <button className="button button2" onClick={() => navigate('/transactions')}>
                Transactions
            </button>
            <button className="button button2" onClick={() => navigate('/provider')}>
                Provider
            </button>
            <button className='button button2' onClick={() => navigate('/ethereum') }>
                ETHEREUM OBJECT IDENTIFICATION
            </button>
        </div>
    )
}

export default Landing