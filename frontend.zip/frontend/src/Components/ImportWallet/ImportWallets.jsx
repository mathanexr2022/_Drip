import React, { useRef } from 'react';
import './ImportWallet.css';

function ImportWallet() {

    const refMnemonics = useRef();
    const refPassword = useRef();
    const refPasswords = useRef();

    const handleClick = async(e) => {

        e.preventDefault();

        console.log("mnemonics", refMnemonics.current.value)
        console.log("password", refPasswords.current)

    }

    return (
        <div className="container">
            <form onSubmit={handleClick}>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="mnemonics">Mnemonics</label>
                    </div>
                    <div className="col-75">
                        <input ref={refMnemonics} type="text" id="mnemonics" name="seed" placeholder="Mnemonics...." />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="passwd">New Password</label>
                    </div>
                    <div className="col-75">
                        <input ref={refPassword} type="text" id="passwd" name="password" placeholder="Password...." />
                    </div>
                </div>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="cpasswd">Confirm Password</label>
                    </div>
                    <div className="col-75">
                        <input type="text" id="cpasswd" name="cpassword" placeholder="Password...." />
                    </div>
                </div>
                <br />
                <div className="row">
                    <input type="submit" value="Submit" />
                </div>
            </form>

        </div>
    )
}

export default ImportWallet