import React from 'react'
import { useState } from 'react'
import axios from '../../axios';

function Provider() {

    const [abi, setAbi] = useState();
    const [contractAddress, setContractAddress] = useState();
   const [chain, setChain] = useState();
    const [provider, setProvider] = useState();

    const selectProvider = async (chainid) => {

        try {

            let options = {
                chainId: chainid
            }

            await axios.post('/wallet/setProvider', options)
                .then(function (response) {
                    console.log(response.data.message);
                    setProvider(response.data.message);
                    setChain(chainid)
                })
                .catch(function (error) {
                    console.log(error);
                });

        } catch (error) {

            console.log(":: CREATE_NEW_WALLET ::", error);
            return false;

        }

    }


    const generateAbi = async (e) => {

        e.preventDefault();

        try {

            let options = {
                address: contractAddress,
                chainId: chain
            }

            await axios.post('/contract/importAbi', options)
                .then(function (response) {
                    console.log(response.data.message);
                    setAbi(response.data.message);
                })
                .catch(function (error) {
                    console.log(error);
                });

        } catch (error) {

            console.log(":: CREATE_NEW_WALLET ::", error);
            return false;

        }

    }


    return (
        <div className="container">
            <div className="row">
                <input type="submit" value="Polygon" onClick={async() => {
                     selectProvider('8001');
                }} />
            </div>
            <div className="row">
                <input type="submit" value="Ethereum" onClick={async() => {
                      selectProvider('3')
                }} />
            </div>
            <form onSubmit={generateAbi}>
                <div className="row">
                    <div className="col-25">
                        <label htmlFor="passwd">Contract Address</label>
                    </div>
                    <div className="col-75">
                        <input type="text" id="passwd" name="password" placeholder="Contract Address...." onChange={(e) => setContractAddress(e.target.value) } />
                    </div>
                </div>
                <br />
                <div className="row">
                    <input type="submit" value="Submit" />
                </div>
            </form>

        </div>
    )
}

export default Provider