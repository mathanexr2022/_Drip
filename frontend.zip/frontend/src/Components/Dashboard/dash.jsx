import React from 'react';
import { useState,useEffect } from 'react';
import './Dashboard.css';
import axios from '../../axios';
import Dashboard from './Dashboard';


function Dash(){
   //* Create Account  
   const [mnemonics, setMnemonics] = useState();
   const [exportedPrivateKey, setExportedPrivateKey] = useState();
   const [exported_address, setExportedAddress] = useState();
  


   const createAccount = async(e)=>{
    e.preventDefault()
    try {
      let obj = {}
      //* reading from local
       chrome.storage.local.get(['wallet_data'], (read_data) => {
        obj.data = read_data.wallet_data.message
        axios.post('/crypto/decrypt', obj)
          .then((result) => {
            console.log("result FORMAT ---------->", result.data.message);
            setMnemonics(result.data.message.mnemonics);
            console.log("printing mnemonics set",mnemonics)
          }).catch(function (error) {
            console.log(error);
          })
      });
      
    } catch (error) {
      console.log(error);
      
    }
   }


   return(
    <>
    <h5>{mnemonics}</h5>
    <button className="button button2" onClick={createAccount}>
        Create Account
      </button>
    </>
   )
}



export default Dash